Array3d v(2,3,4), w(4,2,3);
cout << v.min(w) << endl;
